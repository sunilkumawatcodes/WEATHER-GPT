CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE favorites(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,lat REAL,lon REAL,created_at TEXT NOT NULL);
CREATE TABLE ai_conversations(id INTEGER PRIMARY KEY AUTOINCREMENT,location TEXT,question TEXT,answer TEXT,language TEXT,created_at TEXT NOT NULL);
CREATE TABLE risk_assessments(id INTEGER PRIMARY KEY AUTOINCREMENT,location TEXT,score INTEGER,band TEXT,factors TEXT,created_at TEXT NOT NULL);
CREATE TABLE travel_plans(id INTEGER PRIMARY KEY AUTOINCREMENT,origin TEXT,destination TEXT,start_date TEXT,end_date TEXT,result TEXT,created_at TEXT NOT NULL);
