import rateLimit from 'express-rate-limit';
export const apiLimiter=rateLimit({windowMs:60_000,max:120,standardHeaders:'draft-8',legacyHeaders:false,message:{error:'Too many requests. Please retry shortly.'}});
export const aiLimiter=rateLimit({windowMs:60_000,max:20,standardHeaders:'draft-8',legacyHeaders:false,message:{error:'AI request limit reached. Please retry shortly.'}});
