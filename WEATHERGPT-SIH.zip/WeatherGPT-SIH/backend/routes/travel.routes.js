import {Router} from 'express';import {analyzeTravel} from '../services/travel.service.js';import {getWeather} from '../services/weather.service.js';
const r=Router();r.post('/analyze',async(req,res,next)=>{try{res.json(await analyzeTravel({...req.body,getWeather}))}catch(e){next(e)}});export default r;
