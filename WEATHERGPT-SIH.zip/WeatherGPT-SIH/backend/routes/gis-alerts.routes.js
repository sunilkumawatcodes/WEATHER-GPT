import { Router } from 'express';
import { getWeather } from '../services/weather.service.js';
import { calculateRisk } from '../services/risk.service.js';
import { buildGISAlerts } from '../services/gis-alerts.service.js';

const r = Router();
r.get('/', async (req, res, next) => {
  try {
    const lat = Number(req.query.lat); const lon = Number(req.query.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return res.status(400).json({ error: 'lat and lon are required' });
    const weather = await getWeather({ lat, lon, name: req.query.name || 'Location' });
    const risk = calculateRisk(weather);
    res.json({ alerts: buildGISAlerts(weather, risk), risk });
  } catch (e) { next(e); }
});
export default r;
