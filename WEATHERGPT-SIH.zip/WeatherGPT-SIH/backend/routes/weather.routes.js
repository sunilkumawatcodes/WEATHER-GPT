import {Router} from 'express';import {geocode,getWeather} from '../services/weather.service.js';import {calculateRisk} from '../services/risk.service.js';
const r=Router();
r.get('/geocode',async(req,res,next)=>{try{res.json(await geocode(String(req.query.q||'')))}catch(e){next(e)}});
r.get('/current',async(req,res,next)=>{try{res.json(await getWeather({lat:Number(req.query.lat),lon:Number(req.query.lon),name:String(req.query.name||'Location')}))}catch(e){next(e)}});
r.get('/risk',async(req,res,next)=>{try{const w=await getWeather({lat:Number(req.query.lat),lon:Number(req.query.lon),name:String(req.query.name||'Location')});const risk=calculateRisk(w);res.json({weather:w,risk})}catch(e){next(e)}});
export default r;
