import { GoogleGenAI } from '@google/genai';
let client;
function getClient(){if(!process.env.GEMINI_API_KEY)return null;client??=new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});return client;}
const system=`You are WeatherGPT, an evidence-grounded weather intelligence assistant for an SIH prototype. Use ONLY the supplied weather context for current conditions and forecast facts. Never invent sensor readings, warnings, or certainty. Explain clearly for ordinary users. For safety-critical questions, advise following official local authorities. Provide practical actions, reasons, timing, uncertainty, and confidence when useful. Answer in the requested language.`;
export async function askGemini({question,weather,language='en',mode='general'}){
 const ai=getClient(); const context=JSON.stringify({language,mode,weather});
 if(!ai)return `Demo AI mode: Based on the supplied weather data, ${weather.current.description}, ${Math.round(weather.current.temp)}°C, humidity ${weather.current.humidity}%, wind ${weather.current.wind_speed} m/s. Your question was: “${question}”. Add GEMINI_API_KEY to enable Gemini-generated detailed answers.`;
 const interaction=await ai.interactions.create({model:process.env.GEMINI_MODEL||'gemini-3.8-flash',input:[{role:'user',content:[{type:'text',text:`Weather context: ${context}\nQuestion: ${question}`}]}],system_instruction:system});
 return interaction.output_text || 'No AI response was returned.';
}
