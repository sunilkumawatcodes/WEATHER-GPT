import { GoogleGenAI } from '@google/genai';

let client;
const SYSTEM = `You are WeatherGPT AI Service. You answer weather, forecast, climate, disaster-risk, travel-weather and farmer decision questions. Use supplied structured data as the factual source. Never invent live readings, warnings, routes, sensor values or official alerts. Explain in simple language, with sections: Answer, Why, What to do, Timing, and Safety when relevant. The deterministic risk engine owns the numeric risk score. If information is missing, say so. Respond in the requested language.`;

function getClient() {
  if (!process.env.GEMINI_API_KEY) return null;
  client ??= new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  return client;
}

export async function generateWeatherAnswer({ question, context, language = 'en', mode = 'general' }) {
  const ai = getClient();
  if (!ai) {
    return `Demo AI Service: Gemini is not configured. Mode=${mode}. The supplied weather/risk context is available to the application. Add GEMINI_API_KEY on the backend to enable detailed AI answers in ${language}.`;
  }
  const prompt = [
    `Language: ${language}`,
    `Mode: ${mode}`,
    `User question: ${question}`,
    `Structured context: ${JSON.stringify(context)}`
  ].join('\n');
  const response = await ai.models.generateContent({
    model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
    contents: prompt,
    config: { systemInstruction: SYSTEM, temperature: 0.2 }
  });
  return response.text || 'The AI service returned no text.';
}
