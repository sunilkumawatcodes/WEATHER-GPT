const ALERT_RULES = [
  { type: 'HEAVY_RAIN', severity: 'HIGH', test: w => Number(w?.current?.rain_1h || 0) >= 20 || Number(w?.daily?.[0]?.rain || 0) >= 50, message: 'Heavy rainfall may cause waterlogging or local flooding.' },
  { type: 'EXTREME_HEAT', severity: 'HIGH', test: w => Number(w?.current?.temp || 0) >= 43, message: 'Extreme heat conditions detected.' },
  { type: 'HIGH_WIND', severity: 'HIGH', test: w => Number(w?.current?.wind_speed || 0) >= 17, message: 'Strong winds may affect travel and loose structures.' },
  { type: 'THUNDERSTORM', severity: 'HIGH', test: w => Boolean(w?.current?.thunderstorm), message: 'Thunderstorm signal detected; seek shelter if storms develop.' },
  { type: 'LOW_VISIBILITY', severity: 'MODERATE', test: w => Number(w?.current?.visibility || 10) <= 2, message: 'Low visibility may make travel hazardous.' }
];

export function buildGISAlerts(weather, risk = null) {
  const alerts = ALERT_RULES.filter(rule => rule.test(weather)).map(rule => ({
    id: `${rule.type}-${Date.now()}`,
    type: rule.type,
    severity: rule.severity,
    title: rule.type.replaceAll('_', ' '),
    message: rule.message,
    source: 'WeatherGPT decision engine',
    official: false
  }));
  if (risk?.score >= 75 && !alerts.some(a => a.severity === 'CRITICAL')) {
    alerts.push({ id: `RISK-${Date.now()}`, type: 'COMPOUND_RISK', severity: 'CRITICAL', title: 'Compound weather risk', message: 'Multiple weather factors combine into a critical decision-support score.', source: 'WeatherGPT risk engine', official: false });
  }
  return alerts;
}
