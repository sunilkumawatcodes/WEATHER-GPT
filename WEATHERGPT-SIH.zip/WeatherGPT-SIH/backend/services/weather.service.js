const OWM='https://api.openweathermap.org';
const cache=new Map();
const key=process.env.OPENWEATHER_API_KEY;
function demo(lat,lon,name='Demo Location'){
 const now=Math.floor(Date.now()/1000); const hourly=Array.from({length:24},(_,i)=>({dt:now+i*3600,temp:24+Math.round(4*Math.sin(i/3)),pop:i%7===3?.55:i%5===0?.2:.05,weather:[{main:i%6===3?'Rain':'Clouds',description:i%6===3?'light rain':'partly cloudy',icon:i%6===3?'10d':'03d'}],wind_speed:3+i%4}));
 return {location:{name,lat,lon},current:{temp:26,feels_like:27,humidity:64,wind_speed:4,pressure:1012,visibility:10000,description:'Partly cloudy',icon:'03d',rain:0},hourly,daily:Array.from({length:7},(_,i)=>({dt:now+i*86400,temp:{min:20,max:30+i%3},pop:.12+i*.07,weather:[{main:i===3?'Rain':'Clouds',description:i===3?'showers':'partly cloudy',icon:i===3?'10d':'03d'}]})),alerts:[]};
}
async function fetchJson(url){const r=await fetch(url);if(!r.ok)throw new Error(`Weather provider error ${r.status}`);return r.json();}
export async function geocode(q){
 if(!q) throw Object.assign(new Error('Location is required'),{status:400});
 if(!key){return [{name:q,lat:17.385,lon:78.4867,state:'Demo',country:'IN'}];}
 return fetchJson(`${OWM}/geo/1.0/direct?q=${encodeURIComponent(q)}&limit=5&appid=${key}`);
}
export async function getWeather({lat,lon,name='Location'}){
 const cacheKey=`${lat.toFixed(3)},${lon.toFixed(3)}`; const hit=cache.get(cacheKey); if(hit && hit.expires>Date.now()) return hit.data;
 if(!key){const d=demo(lat,lon,name);cache.set(cacheKey,{data:d,expires:Date.now()+60_000});return d;}
 const [c,f]=await Promise.all([
  fetchJson(`${OWM}/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${key}`),
  fetchJson(`${OWM}/data/2.5/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${key}`)
 ]);
 const hourly=f.list.slice(0,24).map(x=>({dt:x.dt,temp:x.main.temp,pop:x.pop||0,weather:x.weather,wind_speed:x.wind.speed}));
 const byDay={}; for(const x of f.list){const day=new Date(x.dt*1000).toISOString().slice(0,10);(byDay[day]??=[]).push(x)}
 const daily=Object.values(byDay).slice(0,7).map(xs=>({dt:xs[0].dt,temp:{min:Math.min(...xs.map(x=>x.main.temp_min)),max:Math.max(...xs.map(x=>x.main.temp_max))},pop:Math.max(...xs.map(x=>x.pop||0)),weather:[xs[Math.floor(xs.length/2)]?.weather?.[0]||xs[0].weather[0]]}));
 const data={location:{name:c.name,lat:c.coord.lat,lon:c.coord.lon},current:{temp:c.main.temp,feels_like:c.main.feels_like,humidity:c.main.humidity,wind_speed:c.wind.speed,pressure:c.main.pressure,visibility:c.visibility,description:c.weather?.[0]?.description||'',icon:c.weather?.[0]?.icon||'01d',rain:c.rain?.['1h']||0},hourly,daily,alerts:[]};
 cache.set(cacheKey,{data,expires:Date.now()+120_000}); return data;
}
