# Architecture

```text
                    ┌─────────────────────────┐
                    │     WeatherGPT UI       │
                    │ HTML/CSS/Vanilla JS     │
                    └───────────┬─────────────┘
                                │ REST/JSON
                    ┌───────────▼─────────────┐
                    │     Express Backend     │
                    │ Helmet • CORS • Limits  │
                    └──────┬─────┬──────┬─────┘
                           │     │      │
                ┌──────────▼┐ ┌──▼───┐ ┌▼─────────────┐
                │ Weather   │ │Gemini│ │ Decision     │
                │ Provider  │ │ AI   │ │ Engines      │
                └──────────┘ └──────┘ │ Risk/Farmer/ │
                                       │ Travel       │
                                       └──────┬───────┘
                                              │
                                       ┌──────▼───────┐
                                       │ SQLite/Postgres│
                                       └───────────────┘
```
