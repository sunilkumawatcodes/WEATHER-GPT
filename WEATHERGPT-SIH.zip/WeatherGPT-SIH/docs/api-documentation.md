# API Documentation

## GET /api/weather/current
Query: `lat`, `lon`, optional `name`.

## POST /api/ai/chat
```json
{"question":"Will it rain today?","lat":17.385,"lon":78.4867,"name":"Hyderabad","language":"en","mode":"general"}
```

## POST /api/farmer/advice
```json
{"crop":"Cotton","action":"spray","lat":17.385,"lon":78.4867,"name":"Hyderabad","language":"te"}
```

## POST /api/travel/analyze
```json
{"from":"Hyderabad","to":"Mumbai","startDate":"2026-09-10","endDate":"2026-09-12"}
```
