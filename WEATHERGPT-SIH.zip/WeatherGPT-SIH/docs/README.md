# WeatherGPT — SIH Ready Package

This package preserves the supplied WeatherGPT prototype UI and adds a production-oriented Node/Express backend, SQLite persistence, weather integration, Gemini AI integration, risk engine, farmer advisory, travel analysis, multilingual UI hooks, voice support, and map layers.

## 1. Requirements
- Node.js 20+
- OpenWeather API key (recommended for live weather)
- Gemini API key (recommended for AI)
- Internet access for Leaflet/OSM/Esri tiles and optional OSRM routing

## 2. Run locally
```bash
cd backend
cp .env.example .env
# edit .env and add OPENWEATHER_API_KEY and GEMINI_API_KEY
npm install
npm start
```
Open http://localhost:3000

The application intentionally has a demo weather mode when no OpenWeather key is configured, so the SIH demo can still start and the UI can be evaluated.

## 3. Architecture
Browser → Express API → weather/geocoding services + risk engine + Gemini + SQLite.

API endpoints:
- GET /api/health
- GET /api/weather/geocode?q=
- GET /api/weather/current?lat=&lon=&name=
- GET /api/weather/risk?lat=&lon=&name=
- POST /api/ai/chat
- POST /api/farmer/advice
- POST /api/travel/analyze
- GET/POST /api/settings

## 4. Security
- Secrets remain in backend environment variables.
- Helmet security headers.
- CORS configuration.
- API and AI rate limits.
- JSON input size limit.
- No API keys embedded in frontend JavaScript.
- SQLite WAL mode.

## 5. SIH demo flow
Search a city/village → live forecast → risk score → Ask AI → Farmer Decision Mode → Travel Hazard Analyzer → multilingual/voice response.

## 6. Production hardening before deployment
- Replace public demo routing with an approved routing provider.
- Add authentication and per-user authorization if multi-user accounts are required.
- Use PostgreSQL for high-concurrency deployments.
- Add Redis for distributed rate limits/cache.
- Add monitoring, structured logs, backups and HTTPS.
- Use official/local warning feeds and validate every severe-weather alert before display.
- Add automated integration tests against staging APIs.
