# Datasets, Models, GIS Alerts & AI Service

## Dataset
`data/datasets/` contains small demonstration datasets for development and SIH demonstration. They are synthetic/curated samples and must not be presented as official historical weather observations.

## Models
`models/` contains versioned deterministic model specifications. The risk model calculates the displayed 0-100 score; Gemini explains it.

## GIS Alerts
`backend/services/gis-alerts.service.js` creates map-ready decision-support alerts from weather/risk inputs. Alerts are explicitly marked `official:false`; official warnings should come from an authenticated official provider when available.

## AI Service
`ai-service/` provides an optional separate Gemini microservice. The same generation module is shared with the main backend.
