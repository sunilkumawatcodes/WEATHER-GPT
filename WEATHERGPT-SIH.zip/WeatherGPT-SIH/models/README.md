# WeatherGPT Models

This directory contains transparent, versioned decision-model specifications used by WeatherGPT.

## Model policy
- `risk-model.json` is a deterministic scoring model. It is the source of the displayed 0-100 risk score.
- `farmer-model.json` contains crop/action rules used before AI explanation.
- Gemini is an explanation and reasoning layer. It must not invent the numeric risk score.

The CSV files in `data/datasets/` are demonstration/training-style samples, not an official meteorological dataset. Replace them with validated historical observations before any ML training or operational claims.
