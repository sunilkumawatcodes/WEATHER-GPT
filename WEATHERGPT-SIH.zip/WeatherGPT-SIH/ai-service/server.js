import 'dotenv/config';
import express from 'express';
import { generateWeatherAnswer } from '../backend/services/ai-service.js';

const app = express();
app.use(express.json({ limit: '1mb' }));
app.get('/health', (_, res) => res.json({ ok: true, service: 'WeatherGPT AI Service', configured: Boolean(process.env.GEMINI_API_KEY) }));
app.post('/generate', async (req, res) => {
  try {
    const { question, context = {}, language = 'en', mode = 'general' } = req.body;
    if (!question) return res.status(400).json({ error: 'question is required' });
    const answer = await generateWeatherAnswer({ question, context, language, mode });
    res.json({ answer });
  } catch (error) {
    res.status(502).json({ error: 'AI generation failed', detail: error.message });
  }
});
app.listen(Number(process.env.AI_PORT || 4100), () => console.log(`AI service running on http://localhost:${process.env.AI_PORT || 4100}`));
