# WeatherGPT AI Service

Optional standalone AI microservice. The main backend can also call the same service module directly.

Endpoint:
- GET /health
- POST /generate

Keep `GEMINI_API_KEY` server-side. Do not place it in frontend JavaScript.
