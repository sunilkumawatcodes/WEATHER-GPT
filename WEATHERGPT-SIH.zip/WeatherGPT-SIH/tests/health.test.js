import test from 'node:test';import assert from 'node:assert/strict';
test('risk thresholds remain bounded',async()=>{const {calculateRisk}=await import('../backend/services/risk.service.js');const w={current:{temp:45,wind_speed:20,visibility:1000},hourly:[{pop:1}]};const r=calculateRisk(w);assert.equal(r.score,100);assert.equal(r.band,'CRITICAL')});
