const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const { env } = require('../config/env');

function securityMiddleware(app) {
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
  app.use((req, res, next) => {
    const id = req.headers['x-request-id'] || crypto.randomUUID();
    res.setHeader('X-Request-Id', id);
    req.requestId = id;
    next();
  });
  app.use(rateLimit({ windowMs: env.rateLimitWindowMs, limit: env.rateLimitMax, standardHeaders: 'draft-8', legacyHeaders: false }));
}

const aiLimiter = rateLimit({
  windowMs: env.rateLimitWindowMs,
  limit: env.aiRateLimitMax,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'AI request limit reached. Please wait a moment and try again.' }
});

module.exports = { securityMiddleware, aiLimiter };
