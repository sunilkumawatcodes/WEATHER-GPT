const path = require('path');
require('dotenv').config();

function int(name, fallback, min, max) {
  const value = Number(process.env[name] ?? fallback);
  if (!Number.isInteger(value) || value < min || value > max) throw new Error(`${name} must be an integer between ${min} and ${max}`);
  return value;
}

const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: int('PORT', 3000, 1, 65535),
  dbPath: process.env.DB_PATH || path.join(__dirname, '..', '..', 'data', 'weathergpt.db'),
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  geminiModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
  maxBodyBytes: process.env.MAX_BODY_BYTES || '128kb',
  rateLimitWindowMs: int('RATE_LIMIT_WINDOW_MS', 60_000, 1000, 3_600_000),
  rateLimitMax: int('RATE_LIMIT_MAX', 60, 1, 10_000),
  aiRateLimitMax: int('AI_RATE_LIMIT_MAX', 12, 1, 1000),
  weatherCacheSeconds: int('WEATHER_CACHE_SECONDS', 120, 0, 86_400),
  mapProvider: process.env.MAP_PROVIDER || 'leaflet-osm',
  mapboxAccessToken: process.env.MAPBOX_ACCESS_TOKEN || ''
};

module.exports = { env };
