function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

function badRequest(message) {
  const error = new Error(message);
  error.statusCode = 400;
  return error;
}

function parseCoordinate(value, min, max, name) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < min || n > max) throw badRequest(`Invalid ${name}`);
  return n;
}

function clampInt(value, fallback, min, max) {
  const n = Number(value ?? fallback);
  if (!Number.isInteger(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

module.exports = { asyncRoute, badRequest, parseCoordinate, clampInt };
