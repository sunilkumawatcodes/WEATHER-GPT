const express = require('express');
const db = require('../db');
const { env } = require('../config/env');
const { geocode, reverseGeocode, forecast, airQuality } = require('../services/weather');
const { answer } = require('../services/gemini');
const { asyncRoute, badRequest, parseCoordinate, clampInt } = require('../utils/http');
const { aiLimiter } = require('../middleware/security');

const router = express.Router();
const LANGS = new Set(['en','te','hi','mr','kn','ta']);

router.get('/health', (req, res) => {
  const dbOk = Boolean(db.prepare('SELECT 1 AS ok').get()?.ok);
  res.json({ ok: dbOk, service: 'WeatherGPT API', aiConfigured: Boolean(env.geminiApiKey), database: dbOk ? 'SQLite connected' : 'SQLite error', environment: env.nodeEnv, version: '4.2.0' });
});

router.get('/geocode', asyncRoute(async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 120);
  if (q.length < 2) throw badRequest('Place query is too short');
  const lang = LANGS.has(req.query.lang) ? req.query.lang : 'en';
  const results = await geocode(q, lang);
  if (results[0]) db.prepare('INSERT INTO searches(query,place,latitude,longitude,language) VALUES(?,?,?,?,?)').run(q, results[0].name, results[0].latitude, results[0].longitude, lang);
  res.json({ results });
}));

router.get('/reverse-geocode', asyncRoute(async (req, res) => {
  const lat = parseCoordinate(req.query.lat, -90, 90, 'latitude');
  const lon = parseCoordinate(req.query.lon, -180, 180, 'longitude');
  res.json(await reverseGeocode(lat, lon));
}));

router.get('/weather', asyncRoute(async (req, res) => {
  const lat = parseCoordinate(req.query.lat, -90, 90, 'latitude');
  const lon = parseCoordinate(req.query.lon, -180, 180, 'longitude');
  const days = clampInt(req.query.days, 7, 1, 16);
  const weather = await forecast(lat, lon, days);
  res.set('Cache-Control', 'private, max-age=60');
  res.json(weather);
}));

router.get('/air-quality', asyncRoute(async (req, res) => {
  const lat = parseCoordinate(req.query.lat, -90, 90, 'latitude');
  const lon = parseCoordinate(req.query.lon, -180, 180, 'longitude');
  res.json(await airQuality(lat, lon));
}));

router.post('/ai', aiLimiter, asyncRoute(async (req, res) => {
  const question = String(req.body.question || req.body.prompt || '').trim();
  if (!question || question.length > 4000) throw badRequest('Question is required and must be at most 4000 characters');
  const language = LANGS.has(req.body.language) ? req.body.language : 'en';
  const place = String(req.body.location || '').trim().slice(0, 160);
  let weather = req.body.weather;
  if (!weather && Number.isFinite(Number(req.body.latitude)) && Number.isFinite(Number(req.body.longitude))) {
    weather = await forecast(Number(req.body.latitude), Number(req.body.longitude), 7);
  }
  if (!weather) throw badRequest('Live weather context is required');
  const history = Array.isArray(req.body.history) ? req.body.history.slice(-8).map(x => ({ role: String(x.role || '').slice(0, 20), text: String(x.text || '').slice(0, 1200) })) : [];
  const text = await answer({ question, language, place, weather, history });
  db.prepare('INSERT INTO ai_chats(question,answer,location,language) VALUES(?,?,?,?)').run(question, text, place, language);
  res.json({ text, model: env.geminiModel, provider: 'Google Gemini' });
}));

router.post('/places', asyncRoute(async (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 120);
  const lat = parseCoordinate(req.body.latitude, -90, 90, 'latitude');
  const lon = parseCoordinate(req.body.longitude, -180, 180, 'longitude');
  if (!name) throw badRequest('Place name required');
  db.prepare(`INSERT INTO saved_places(name,latitude,longitude) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET latitude=excluded.latitude, longitude=excluded.longitude`).run(name, lat, lon);
  res.json({ ok: true });
}));

router.get('/history', (req, res) => res.json(db.prepare('SELECT id,query,place,latitude,longitude,language,created_at FROM searches ORDER BY id DESC LIMIT 50').all()));
router.get('/chats', (req, res) => res.json(db.prepare('SELECT id,question,answer,location,language,created_at FROM ai_chats ORDER BY id DESC LIMIT 50').all()));
router.get('/places', (req, res) => res.json(db.prepare('SELECT id,name,latitude,longitude,created_at FROM saved_places ORDER BY name').all()));
router.get('/cyclones', asyncRoute(async (req, res) => {
  const r = await fetch('https://www.gdacs.org/contentdata/xml/gdacsTC.geojson', { signal: AbortSignal.timeout(12000) });
  if (!r.ok) throw new Error('GDACS cyclone feed unavailable');
  const j = await r.json();
  const cutoff = Date.now() - 8 * 24 * 60 * 60 * 1000;
  const features = (j.features || []).filter(f => {
    const p=f.properties||{};
    const d=Date.parse(p.todate||p.fromdate||p.date||'');
    return !Number.isFinite(d) || d >= cutoff;
  });
  res.set('Cache-Control','public, max-age=300');
  res.json({type:'FeatureCollection',features,source:'GDACS'});
}));

router.get('/map-config', (req, res) => res.json({ mapProvider: env.mapProvider, mapboxConfigured: Boolean(env.mapboxAccessToken), radarProvider: 'RainViewer', satelliteProvider: 'Esri World Imagery' }));

module.exports = router;
