const { env } = require('../config/env');

const cache = new Map();
const airCache = new Map();

function cacheKey(lat, lon, days) { return `${lat.toFixed(3)}:${lon.toFixed(3)}:${days}`; }
function airKey(lat, lon) { return `${lat.toFixed(3)}:${lon.toFixed(3)}`; }

async function fetchJson(url, timeoutMs = 10000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json', 'User-Agent': 'WeatherGPT/3.0' }
    });
    if (!response.ok) throw Object.assign(new Error(`Provider returned ${response.status}`), { statusCode: 502 });
    return await response.json();
  } finally { clearTimeout(timer); }
}

async function geocode(query, language = 'en') {
  const url = new URL('https://geocoding-api.open-meteo.com/v1/search');
  url.search = new URLSearchParams({ name: query, count: '20', language: 'en', format: 'json' });
  const data = await fetchJson(url);
  return (data.results || []).map(x => ({
    name: x.name, latitude: x.latitude, longitude: x.longitude,
    country: x.country, country_code: x.country_code, admin1: x.admin1,
    timezone: x.timezone, population: x.population
  })).sort((a,b) => {
    const ai = (a.country_code === 'IN' ? 1000000000 : 0) + (a.population || 0);
    const bi = (b.country_code === 'IN' ? 1000000000 : 0) + (b.population || 0);
    return bi - ai;
  });
}

async function reverseGeocode(latitude, longitude) {
  const url = new URL('https://nominatim.openstreetmap.org/reverse');
  url.search = new URLSearchParams({ lat: latitude, lon: longitude, format: 'jsonv2', zoom: '18', addressdetails: '1' });
  const data = await fetchJson(url, 10000);
  const a = data.address || {};
  return {
    name: a.village || a.town || a.city || a.municipality || a.suburb || a.county || 'My location',
    village: a.village || '', town: a.town || '', city: a.city || '',
    state: a.state || a.state_district || '', district: a.state_district || a.county || '',
    country: a.country || '', country_code: (a.country_code || '').toUpperCase(),
    latitude: Number(latitude), longitude: Number(longitude), timezone: data.timezone || null
  };
}

async function airQuality(latitude, longitude) {
  const key = airKey(latitude, longitude);
  const cached = airCache.get(key);
  if (cached && Date.now() - cached.time < env.weatherCacheSeconds * 1000) return cached.data;
  const url = new URL('https://air-quality-api.open-meteo.com/v1/air-quality');
  url.search = new URLSearchParams({
    latitude, longitude, timezone: 'auto', forecast_days: '5',
    current: 'european_aqi,us_aqi,pm2_5,pm10,carbon_monoxide,nitrogen_dioxide,ozone',
    hourly: 'pm2_5,pm10,european_aqi,us_aqi'
  });
  try {
    const data = await fetchJson(url, 9000);
    airCache.set(key, { time: Date.now(), data });
    return data;
  } catch (error) {
    return { unavailable: true, error: 'Air quality provider unavailable' };
  }
}

async function forecast(latitude, longitude, days = 7) {
  const key = cacheKey(latitude, longitude, days);
  const cached = cache.get(key);
  if (cached && Date.now() - cached.time < env.weatherCacheSeconds * 1000) return cached.data;

  const url = new URL('https://api.open-meteo.com/v1/forecast');
  url.search = new URLSearchParams({
    latitude, longitude, timezone: 'auto', forecast_days: days,
    current: [
      'temperature_2m','relative_humidity_2m','apparent_temperature','precipitation','rain','showers','snowfall',
      'weather_code','cloud_cover','pressure_msl','wind_speed_10m','wind_direction_10m','wind_gusts_10m','is_day'
    ].join(','),
    hourly: [
      'temperature_2m','relative_humidity_2m','dew_point_2m','apparent_temperature','precipitation_probability',
      'precipitation','rain','showers','snowfall','weather_code','cloud_cover','visibility','pressure_msl',
      'wind_speed_10m','wind_direction_10m','wind_gusts_10m','uv_index','et0_fao_evapotranspiration',
      'soil_temperature_0_to_7cm','soil_moisture_0_to_7cm'
    ].join(','),
    daily: [
      'weather_code','temperature_2m_max','temperature_2m_min','apparent_temperature_max','apparent_temperature_min',
      'precipitation_probability_max','precipitation_sum','rain_sum','showers_sum','snowfall_sum','precipitation_hours',
      'sunrise','sunset','daylight_duration','sunshine_duration','uv_index_max','wind_speed_10m_max','wind_gusts_10m_max',
      'wind_direction_10m_dominant','et0_fao_evapotranspiration'
    ].join(',')
  });

  const [weather, air] = await Promise.all([fetchJson(url), airQuality(latitude, longitude)]);
  weather.airQuality = air;
  weather.meta = {
    provider: 'Open-Meteo',
    fetchedAt: new Date().toISOString(),
    cacheSeconds: env.weatherCacheSeconds
  };
  cache.set(key, { time: Date.now(), data: weather });
  return weather;
}

module.exports = { geocode, reverseGeocode, forecast, airQuality };
