const express = require('express');
const path = require('path');
const compression = require('compression');
const { env } = require('./src/config/env');
require('./src/db');
const api = require('./src/routes/api');
const { securityMiddleware } = require('./src/middleware/security');

const app = express();
securityMiddleware(app);
app.use(compression());
app.use(express.json({ limit: env.maxBodyBytes, strict: true }));
app.use(express.urlencoded({ extended: false, limit: '16kb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: env.nodeEnv === 'production' ? '1d' : 0, etag: true }));
app.use('/api', api);

app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found' }));
app.use((err, req, res, next) => {
  const status = Number(err.statusCode) || (err.name === 'AbortError' ? 504 : 500);
  console.error(`[${req.requestId || 'no-id'}]`, err.message);
  res.status(status).json({ error: status >= 500 ? 'Service temporarily unavailable' : err.message, requestId: req.requestId });
});
app.get(/^(?!\/api(?:\/|$)).*/, (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

const server = app.listen(env.port, () => console.log(`WeatherGPT listening on port ${env.port}`));
function shutdown(signal) { console.log(`${signal}: shutting down`); server.close(() => process.exit(0)); }
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

module.exports = app;
