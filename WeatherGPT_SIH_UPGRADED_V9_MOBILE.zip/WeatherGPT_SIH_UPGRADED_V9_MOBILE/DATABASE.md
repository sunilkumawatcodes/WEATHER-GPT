# WeatherGPT database connection

The application uses SQLite through `better-sqlite3`.

Connection is created in `src/db/index.js` using the `DB_PATH` environment variable:

```env
DB_PATH=./data/weathergpt.db
```

The server automatically creates the database directory and tables from `src/db/schema.sql` when it starts.

Tables:

| Table | Purpose |
|---|---|
| `searches` | Stores searched locations and coordinates |
| `ai_chats` | Stores WeatherGPT AI questions/answers |
| `saved_places` | Stores saved locations |
| `weather_snapshots` | Prepared for persisted weather snapshots |

SQLite uses WAL mode and foreign keys are enabled.

For SIH/demo deployment this is simple and reliable. For high-traffic production with multiple server instances, migrate this layer to PostgreSQL.
