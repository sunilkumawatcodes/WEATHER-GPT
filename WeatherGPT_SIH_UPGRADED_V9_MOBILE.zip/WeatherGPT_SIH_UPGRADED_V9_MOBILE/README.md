# WeatherGPT — Full Stack SIH Build

WeatherGPT keeps the original working prototype UI while adding a real backend, Gemini integration and SQLite persistence.

## Architecture

Browser frontend → Express API → Weather/AQI providers + Gemini → SQLite database

### Frontend
- `public/index.html` — working WeatherGPT UI, map, radar, satellite, forecast, Risk, Travel, Farmer Mode, Daily Ideas, multilingual UI and voice.
- Gemini is called through `/api/ai`; the browser never receives the Gemini API key.

### Backend
- `server.js` — Express entry point.
- `src/routes/api.js` — REST endpoints.
- `src/services/weather.js` — Open-Meteo weather, geocoding and air quality.
- `src/services/gemini.js` — Gemini AI service.
- `src/middleware/security.js` — Helmet, rate limiting and request IDs.
- `src/config/env.js` — validated environment configuration.

### Database
SQLite is initialized automatically at `DB_PATH`.
- `searches` — place searches.
- `ai_chats` — AI questions and answers.
- `saved_places` — saved locations.
- `weather_snapshots` — schema ready for persisted weather snapshots.

## API
- `GET /api/health`
- `GET /api/geocode?q=Hyderabad&lang=en`
- `GET /api/weather?lat=17.385&lon=78.486&days=7`
- `GET /api/air-quality?lat=17.385&lon=78.486`
- `POST /api/ai`
- `POST /api/places`
- `GET /api/places`
- `GET /api/history`
- `GET /api/chats`
- `GET /api/map-config`

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Add your Gemini API key to `.env`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Gemini request example

`POST /api/ai`

```json
{
  "question": "Will it rain today?",
  "language": "en",
  "location": "Hyderabad",
  "latitude": 17.385,
  "longitude": 78.486,
  "history": []
}
```

The server fetches live weather context when coordinates are supplied, then sends that structured context to Gemini. The AI is instructed not to invent missing weather values.

## Production notes

- Keep `.env` private and never commit it.
- Use HTTPS behind a reverse proxy.
- For multiple application servers, replace SQLite with PostgreSQL and move cache/rate limiting to Redis.
- Review provider terms/quotas before public deployment.
