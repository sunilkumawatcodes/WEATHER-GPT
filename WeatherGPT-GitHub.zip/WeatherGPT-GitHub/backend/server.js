import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req,res)=>res.json({ok:true,service:"WeatherGPT backend"}));

app.get("/api/weather", async (req,res)=>{
  try {
    const {latitude, longitude} = req.query;
    if (latitude===undefined || longitude===undefined) return res.status(400).json({error:"latitude and longitude are required"});
    const url = new URL("https://api.open-meteo.com/v1/forecast");
    url.searchParams.set("latitude", latitude); url.searchParams.set("longitude", longitude);
    url.searchParams.set("current","temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m");
    url.searchParams.set("hourly","temperature_2m,precipitation_probability,weather_code,wind_speed_10m");
    url.searchParams.set("daily","weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max");
    url.searchParams.set("timezone","auto"); url.searchParams.set("forecast_days","7");
    const r=await fetch(url); const data=await r.json();
    res.status(r.status).json(data);
  } catch(e){res.status(500).json({error:e.message});}
});

app.get("/api/geocode", async (req,res)=>{
  try {
    const q=(req.query.q||"").trim(); if(!q) return res.status(400).json({error:"q is required"});
    const url=new URL("https://geocoding-api.open-meteo.com/v1/search"); url.searchParams.set("name",q); url.searchParams.set("count","5"); url.searchParams.set("language","en"); url.searchParams.set("format","json");
    const r=await fetch(url); const data=await r.json(); res.status(r.status).json(data);
  } catch(e){res.status(500).json({error:e.message});}
});

app.post("/api/ai", async (req,res)=>{
  try {
    if(!process.env.GEMINI_API_KEY) return res.status(503).json({error:"GEMINI_API_KEY is not configured on the server"});
    const {question, weather, location} = req.body || {};
    if(!question) return res.status(400).json({error:"question is required"});
    const ai = new GoogleGenAI({apiKey: process.env.GEMINI_API_KEY});
    const prompt = `You are WeatherGPT, a concise weather decision assistant. Answer using the supplied live weather data. Do not invent measurements.
Location: ${JSON.stringify(location||{})}
Weather: ${JSON.stringify(weather||{})}
User question: ${question}`;
    const response = await ai.models.generateContent({model: process.env.GEMINI_MODEL || "gemini-3.7-flash", contents: prompt});
    res.json({answer: response.text || "No answer returned."});
  } catch(e){ console.error(e); res.status(500).json({error:e.message}); }
});

app.listen(PORT,()=>console.log(`WeatherGPT backend running on port ${PORT}`));
