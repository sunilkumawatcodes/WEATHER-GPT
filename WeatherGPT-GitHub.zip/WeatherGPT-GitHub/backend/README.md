# WeatherGPT Backend
Express API with Open-Meteo proxy endpoints and Gemini AI. Keep `.env` private.
