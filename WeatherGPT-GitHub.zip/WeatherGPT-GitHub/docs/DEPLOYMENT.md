# Deployment

GitHub can host the static frontend, but the Node/Express backend must run on a server such as Render, Railway, or another Node host. Set the frontend API base URL to that backend URL.
