# WeatherGPT

Mobile-first WeatherGPT split into separate frontend and backend projects.

## Structure
- `frontend/` — HTML, CSS and browser JavaScript.
- `backend/` — Node.js/Express API proxy and Gemini integration.

## Frontend
The frontend uses Leaflet + OpenStreetMap for the map and calls the backend for weather/geocoding/AI. Set `window.API_BASE` in `frontend/js/config.js` to your deployed backend URL when frontend and backend are hosted separately.

## Backend
1. `cd backend`
2. `npm install`
3. Copy `.env.example` to `.env` and set `GEMINI_API_KEY`.
4. `npm start`

Never commit `.env` or API keys. GitHub recommends using `.gitignore` for files that should not be tracked. citeturn0search3

Gemini's current JavaScript SDK is `@google/genai`; Google documents using `GEMINI_API_KEY` as an environment variable. citeturn1search0turn1search6
