
const $=id=>document.getElementById(id);
let state={lat:17.385,lon:78.4867,name:"Hyderabad",weather:null,map:null,marker:null};
const icons={0:"☀️",1:"🌤️",2:"⛅",3:"☁️",45:"🌫️",48:"🌫️",51:"🌦️",53:"🌦️",55:"🌧️",61:"🌧️",63:"🌧️",65:"🌧️",71:"🌨️",73:"🌨️",75:"❄️",80:"🌦️",81:"🌧️",82:"⛈️",95:"⛈️",96:"⛈️",99:"⛈️"};
const desc={0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Rime fog",51:"Light drizzle",53:"Drizzle",55:"Heavy drizzle",61:"Light rain",63:"Rain",65:"Heavy rain",71:"Light snow",73:"Snow",75:"Heavy snow",80:"Rain showers",81:"Rain showers",82:"Heavy showers",95:"Thunderstorm",96:"Thunderstorm with hail",99:"Severe thunderstorm"};
function c(v){return Math.round(v)}
function temp(v){return $("unit").value==="f"?Math.round(v*9/5+32)+"°F":Math.round(v)+"°C"}
function setStatus(t,ok=true){$("status").textContent=t;$("status").style.color=ok?"#59d98e":"#ff8d8d"}
function weatherUrl(lat,lon){return `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation_probability,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=7`}
async function getWeather(lat,lon,name){
 setStatus("Loading live weather…");
 try{
  const r=await fetch(weatherUrl(lat,lon)); if(!r.ok) throw Error("Weather request failed");
  const w=await r.json(); state={...state,lat,lon,name,weather:w}; render(w); updateMap(); setStatus("Live weather connected");
 }catch(e){setStatus("Weather could not be loaded",false);$("condition").textContent=e.message}
}
function render(w){
 $("place").textContent=state.name;
 $("temp").textContent=temp(w.current.temperature_2m);
 $("condition").textContent=`${icons[w.current.weather_code]||"🌤️"} ${desc[w.current.weather_code]||"Weather"} • Feels like ${temp(w.current.apparent_temperature)}`;
 $("humidity").textContent=c(w.current.relative_humidity_2m)+"%";
 $("wind").textContent=c(w.current.wind_speed_10m)+" km/h";
 $("rain").textContent=c(w.daily.precipitation_probability_max[0]||0)+"%";
 $("feels").textContent=temp(w.current.apparent_temperature);
 let h=w.hourly; let now=w.current.time; let start=Math.max(0,h.time.findIndex(x=>x>=now)); $("hourly").innerHTML=h.time.slice(start,start+24).map((t,i)=>`<div class="hour"><div class="t">${new Date(t).toLocaleTimeString([], {hour:"numeric"})}</div><div class="i">${icons[h.weather_code[start+i]]||"🌤️"}</div><b>${temp(h.temperature_2m[start+i])}</b><div class="t">🌧️ ${h.precipitation_probability[start+i]||0}%</div></div>`).join("");
 $("forecast").innerHTML=w.daily.time.map((d,i)=>`<div class="day"><div class="dayname">${i===0?"Today":new Date(d+"T12:00:00").toLocaleDateString([], {weekday:"short"})}</div><div class="dayicon">${icons[w.daily.weather_code[i]]||"🌤️"}</div><b>${temp(w.daily.temperature_2m_max[i])} / ${temp(w.daily.temperature_2m_min[i])}</b><div class="muted">🌧️ ${w.daily.precipitation_probability_max[i]||0}%</div></div>`).join("");
 $("farm").textContent=`${$("crop").value}: current temperature ${temp(w.current.temperature_2m)}, humidity ${c(w.current.relative_humidity_2m)}%, wind ${c(w.current.wind_speed_10m)} km/h. Plan field work around rain and high heat; check local agricultural advisories before spraying.`;
}
async function geocode(q){
 const r=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1&language=en&format=json`);
 const j=await r.json(); if(!j.results?.length) throw Error("Place not found"); return j.results[0];
}
async function searchCity(q){try{let p=await geocode(q);$("city").value=p.name;await getWeather(p.latitude,p.longitude,[p.name,p.admin1,p.country].filter(Boolean).join(", "));}catch(e){setStatus(e.message,false)}}
function initMap(){
 if(state.map)return;
 state.map=L.map("weatherMap",{zoomControl:true,tap:true}).setView([state.lat,state.lon],6);
 L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap contributors"}).addTo(state.map);
}
function updateMap(){initMap(); state.map.setView([state.lat,state.lon],10); if(state.marker)state.map.removeLayer(state.marker); state.marker=L.marker([state.lat,state.lon]).addTo(state.map).bindPopup(`<b>${state.name}</b><br>${state.weather?temp(state.weather.current.temperature_2m):""}`).openPopup(); setTimeout(()=>state.map.invalidateSize(),150)}
function show(page){
 document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===page));
 document.querySelectorAll(".bottom button").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
 if(page==="map"){initMap();updateMap();setTimeout(()=>state.map.invalidateSize(),250)}
 window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll(".bottom button").forEach(b=>b.onclick=()=>show(b.dataset.page));
$("search").onclick=()=>searchCity($("city").value.trim());
$("city").addEventListener("keydown",e=>{if(e.key==="Enter")$("search").click()});
$("loc").onclick=()=>navigator.geolocation?navigator.geolocation.getCurrentPosition(p=>getWeather(p.coords.latitude,p.coords.longitude,"My Location"),()=>setStatus("Location permission was denied",false),{enableHighAccuracy:true}):setStatus("Location is not supported",false);
$("india").onclick=()=>{initMap();state.map.setView([22.5,79],5);setTimeout(()=>state.map.invalidateSize(),150)};
$("center").onclick=()=>{initMap();state.map.setView([state.lat,state.lon],10);setTimeout(()=>state.map.invalidateSize(),150)};
$("unit").onchange=()=>state.weather&&render(state.weather);
$("crop").onchange=()=>state.weather&&render(state.weather);
document.querySelectorAll(".chip").forEach(x=>x.onclick=()=>{$("question").value=x.dataset.q;$("ask").click()});
$("ask").onclick=async()=>{
 const q=$("question").value.trim(); if(!q)return;
 $("answer").textContent="Thinking…";
 try{
  const r=await fetch(`${API_BASE}/api/ai`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question:q,weather:state.weather,location:{name:state.name,latitude:state.lat,longitude:state.lon}})});
  const j=await r.json(); if(!r.ok) throw Error(j.error||"AI server is not connected");
  $("answer").textContent=j.answer||"No answer returned.";
 }catch(e){$("answer").textContent="Gemini is not connected to this standalone file yet. Live weather and map work without it. To use Gemini securely, host the Node/Express backend and open this site through that server."}
};
$("travelBtn").onclick=async()=>{try{let p=await geocode($("to").value);let r=await fetch(weatherUrl(p.latitude,p.longitude));let w=await r.json();$("travelAnswer").textContent=`${p.name}: ${temp(w.current.temperature_2m)}, ${desc[w.current.weather_code]||"Weather"}, rain chance today ${w.daily.precipitation_probability_max[0]||0}%, wind ${c(w.current.wind_speed_10m)} km/h.`}catch(e){$("travelAnswer").textContent=e.message}};
getWeather(state.lat,state.lon,state.name);
