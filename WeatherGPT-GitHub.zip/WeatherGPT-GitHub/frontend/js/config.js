window.API_BASE = window.API_BASE || "";
const API_BASE = window.API_BASE.replace(/\/$/, "");
